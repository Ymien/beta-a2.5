import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import { FontPreload } from '@/components/font-preload';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'PopupMorph | 弹窗形状动画生成器',
    template: '%s | PopupMorph',
  },
  description: '用弹窗组成形状，创建GIF动画效果，自由调整和编辑',
  keywords: [
    'PopupMorph',
    '弹窗动画',
    '形状生成',
    'GIF动画',
  ],
  authors: [{ name: 'PopupMorph' }],
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.COZE_PROJECT_ENV === 'DEV';

  return (
    <html lang="zh-CN">
      <FontPreload />
      <body className={`antialiased`}>
        {isDev && <Inspector />}
        {children}
      </body>
    </html>
  );
}
